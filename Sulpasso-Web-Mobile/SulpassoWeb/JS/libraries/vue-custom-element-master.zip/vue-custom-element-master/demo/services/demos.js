export default {
  basic: 'Basic',
  binding: 'Binding',
  events: 'Events',
  slots: 'Slots',
  'lazy-loading': 'Lazy loading'
};
